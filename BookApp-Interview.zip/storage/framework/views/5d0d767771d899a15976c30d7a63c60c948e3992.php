<?php $__env->startSection('content'); ?>
	<div class="card text-center">
		<div class="card-header">
			<h1><?php echo e($book->title); ?> : </h1>
		</div>
  		<div class="card-body">
    		<p>Released on : <?php echo e($book->release_date); ?></p>
    		<p>Created by : <?php echo e($book->author->name); ?></p>
  		</div>
  		<div class="card-footer">
  			<a href="../books" class="btn btn-default">[ ◄ Go Back ]</a>
  		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>