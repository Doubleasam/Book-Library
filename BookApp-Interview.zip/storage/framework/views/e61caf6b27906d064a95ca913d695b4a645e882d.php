<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header text-center">
			<h1>Create Author</h1>
		</div>
  		<div class="card-body">
    		<?php echo Form::open(['action' => 'authorsController@store', 'methode' => 'POST']); ?>

				<div class="form-group">
					<?php echo e(Form::label('FirstName', 'FirstName')); ?>

					<?php echo e(Form::text('FirstName', '', ['class' => 'form-control', 'placeholder' => 'FirstName'])); ?>

					<?php if($errors->has('FirstName')): ?>
                                <span class="error ">
                                    <strong><?php echo e($errors->first('FirstName')); ?></strong>
                                </span>
					<?php endif; ?>
				          
				</div>
				<div class="form-group">
					<?php echo e(Form::label('LastName', 'LastName')); ?>

					<?php echo e(Form::text('LastName', '', ['class' => 'form-control', 'placeholder' => 'LastName'])); ?>

					<?php if($errors->has('LastName')): ?>
                                <span class="error ">
                                    <strong><?php echo e($errors->first('LastName')); ?></strong>
                                </span>
					<?php endif; ?>
				</div>
				<div class="form-group">
					<?php echo e(Form::label('Email', 'Email')); ?>

					<?php echo e(Form::text('Email', '', ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

					<?php if($errors->has('Email')): ?>
                                <span class="error ">
                                    <strong><?php echo e($errors->first('Email')); ?></strong>
                                </span>
					<?php endif; ?>
				</div>
				<div class="text-center">
					<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

				</div>
			<?php echo Form::close(); ?>

  		</div>
  		<div class="card-footer">
  			<a href="../authors" class="btn btn-default">[ ◄ Go Back ]</a>
  		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>