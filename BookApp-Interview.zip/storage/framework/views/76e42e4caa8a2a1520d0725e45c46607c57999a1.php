<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header text-center">
			<h1>Create Book</h1>
		</div>
  		<div class="card-body">
    		<?php echo Form::open(['action' => 'booksController@store', 'methode' => 'POST']); ?>

				<div class="form-group">
					<?php echo e(Form::label('title', 'Title')); ?>

					<?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

				</div>
				<div class="form-group">
					<?php echo e(Form::label('author', 'Author : ')); ?>

					<?php echo e(Form::select('author', $authors, null, ['class' => 'form-control', 'placeholder' => 'Author'])); ?>

				</div>
				<div class="form-group">
					<?php echo e(Form::label('released_date', 'Released Date : ')); ?>

					<?php echo e(Form::date('released_date', \Carbon\Carbon::now())); ?>

				</div>
				<div class="text-center">
					<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

				</div>
			<?php echo Form::close(); ?>

  		</div>
  		<div class="card-footer">
  			<a href="../books" class="btn btn-default">[ ◄ Go Back ]</a>
  		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>