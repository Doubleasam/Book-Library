<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.css')); ?>">
        <title><?php echo e(config('app.name')); ?></title>

    </head>
    <body>
    	<div><?php echo $__env->make('inc.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
    	<div class="container">
    		<br>
        	<?php echo $__env->yieldContent('content'); ?>
    	</div>
        
        <script type="text/javascript" src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
