<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-header text-center">
			<h1>Create Author</h1>
		</div>
  		<div class="card-body">
    		<?php echo Form::open(['action' => 'authorsController@store', 'methode' => 'POST']); ?>

				<div class="form-group">
					<?php echo e(Form::label('name', 'Name')); ?>

					<?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

				</div>
				<div class="text-center">
					<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

				</div>
			<?php echo Form::close(); ?>

  		</div>
  		<div class="card-footer">
  			<a href="../authors" class="btn btn-default">[ ◄ Go Back ]</a>
  		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>