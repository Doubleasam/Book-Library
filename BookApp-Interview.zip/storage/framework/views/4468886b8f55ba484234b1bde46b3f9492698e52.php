<?php $__env->startSection('content'); ?>
	<h1>Edit Author</h1><br>
	<?php echo Form::open(['action' => ['authorsController@update', $author->id], 'methode' => 'POST', 'enctype' => 'multipart/form-data']); ?>

		<div class="form-group">
			<?php echo e(Form::label('FirstName', 'FirstName')); ?>

			<?php echo e(Form::text('FirstName', $author->FirstName, ['class' => 'form-control', 'placeholder' => 'FirstName'])); ?>

		</div>
		<div class="form-group">
			<?php echo e(Form::label('LastName', 'LastName')); ?>

			<?php echo e(Form::text('LastName', $author->LastName, ['class' => 'form-control', 'placeholder' => 'LastName'])); ?>

		</div>
		<div class="form-group">
			<?php echo e(Form::label('Email', 'Email')); ?>

			<?php echo e(Form::text('Email', $author->Email, ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

		</div>
		<?php echo e(Form::hidden('_method', 'PUT')); ?>

		<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>