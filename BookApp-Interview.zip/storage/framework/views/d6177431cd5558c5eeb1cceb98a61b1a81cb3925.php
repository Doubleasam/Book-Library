<?php $__env->startSection('content'); ?>
	<h1>Edit Book</h1><br>
	<?php echo Form::open(['action' => ['booksController@update', $book->id], 'methode' => 'POST', 'enctype' => 'multipart/form-data']); ?>

		<div class="form-group">
			<?php echo e(Form::label('title', 'Title')); ?>

			<?php echo e(Form::text('title', $book->title, ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

		</div>
		<div class="form-group">
			<?php echo e(Form::label('author', 'Author')); ?>

			<?php echo e(Form::select('author', $author, $book->author_id, ['class' => 'form-control', 'placeholder' => 'Author'])); ?>

		</div>
		<div class="form-group">
			<?php echo e(Form::label('released_date', 'Released Date : ')); ?>

			<?php echo e(Form::date('released_date', \Carbon\Carbon::parse($book->released_date))); ?>

		</div>
		<?php echo e(Form::hidden('_method', 'PUT')); ?>

		<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>