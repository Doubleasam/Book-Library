<?php $__env->startSection('content'); ?>
	<div class="card text-center">
		<?php if($books != null): ?>
      <h6>The author hasn't any book yet</h6>
    <?php else: ?>
      <div class="card-header">
        <h1><?php echo e($books[0]->author->FirstName); ?> : </h1>
        <h1><?php echo e($books[0]->author->LastName); ?> : </h1>
        <h1><?php echo e($books[0]->author->Email); ?> : </h1>
      </div>
      <div class="card-body">
        <ul class="list-group">
          <p>His books : </p>
          <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="list-group-item"><?php echo e($book->title); ?> (<?php echo e($book->release_date); ?>)</li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
        </ul>
      </div>
      <div class="card-footer">
        <a href="../authors" class="btn btn-default">[ ◄ Go Back ]</a>
      </div>
    <?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>