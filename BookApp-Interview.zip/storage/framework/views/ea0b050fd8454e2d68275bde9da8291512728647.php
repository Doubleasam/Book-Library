<?php $__env->startSection('content'); ?>
	<h1>Edit Author</h1><br>
	<?php echo Form::open(['action' => ['authorsController@update', $author->id], 'methode' => 'POST', 'enctype' => 'multipart/form-data']); ?>

		<div class="form-group">
			<?php echo e(Form::label('name', 'Name')); ?>

			<?php echo e(Form::text('name', $author->name, ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

		</div>
		<?php echo e(Form::hidden('_method', 'PUT')); ?>

		<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>